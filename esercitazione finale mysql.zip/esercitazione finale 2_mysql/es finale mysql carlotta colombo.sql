#task 1
#progettazione concettuale tramite excalidraw e progettazione logica tramite draw.io

#task 2

create database es_finale_ToysGroup;
use es_finale_ToysGroup;
create table Product (
	product_id int auto_increment primary key,
    product_name varchar (50),
    category varchar (25));
create table Region (
	sales_region_id int auto_increment primary key,
    sales_region_name varchar (50),
    region_name varchar (25));
create table Sales (
	sales_order_id int auto_increment primary key,
    product_id int,
    order_date date,
    quantity int not null,
    unit_price decimal (12,2),
    constraint fk_Product_Sales foreign key (product_id) references product (product_id));

#task 3

insert into Product (product_name, category) values
	("Bear", "Peluche"),
    ("Cat", "Peluche"),
    ("Panda", "Peluche"),
    ("Barbie", "Doll"),
    ("Action_Man", "Doll"),
    ("Bratz", "Doll"),
    ("Cards", "Collective_Games"),
    ("Puzzle", "Collective_Games"),
    ("Jenga", "Collective_Games");
insert into Region (sales_region_name, region_name) values
	("North_Europe", "UK"),
    ("North_Europe", "Norway"),
    ("East_Europe", "Spain"),
    ("East_Europe", "Portugal"),
    ("East_Europe", "France"),
    ("North_America", "USA"),
    ("North_America", "Canada"),
    ("South_America", "Brasil"),
    ("South_America", "Chile");
insert into Sales (product_id, order_date, quantity, unit_price) values
	(7, "2025-02-13", 2, 7),
    (5, "2025-03-04", 5, 9.5),
    (1, "2025-04-27", 2, 6),
    (2, "2025-09-08", 1, 6.5),
    (7, "2025-08-26", 2, 7);
alter table Sales
add column sales_region_id int,
add foreign key (sales_region_id) references Region (sales_region_id);
select * from Sales;
update Sales
set sales_region_id = 1
where sales_order_id = 1;
update Sales
set sales_region_id = 7
where sales_order_id = 2;
update Sales
set sales_region_id = 6
where sales_order_id = 3;
update Sales
set sales_region_id = 7
where sales_order_id = 4;
update Sales
set sales_region_id = 2
where sales_order_id = 5;

#task 4, 1

select
	product_id,
    count(*)
from Product
group by product_id
having count(*) > 1;
select
	sales_region_id,
    count(*)
from Region
group by sales_region_id
having count(*) > 1;
select
	sales_order_id,
    count(*)
from Sales
group by sales_order_id
having count(*) > 1;

#task 4, 2

select
	s.sales_order_id,
	s.order_date,
    p.product_name,
    p.category,
    r.region_name,
    r.sales_region_name,
    datediff(current_date, s.order_date) as since_shipped,
    datediff(current_date, s.order_date) > 180 as condition_t_or_f
from Sales s
inner join Product p
on s.product_id = p.product_id
inner join Region r
on s.sales_region_id = r.sales_region_id;

#task 4, 3

select
	product_id,
    sum(quantity * unit_price) as sales_amount
from Sales
where year(order_date) = (
	select
		max(year(order_date))
	from Sales)
group by product_id
having sum(quantity) > (
	select
		avg(quantity)
	from Sales);

#task 4, 4

select
	product_id,
    sum(quantity * unit_price) as sales_amount
from Sales
group by
	product_id,
	year(order_date);

#task 4, 5

select
	r.region_name,
    order_date,
    year(order_date) as sales_year,
    sum(quantity * unit_price) as sales_amount
from Region r
inner join Sales s
on r.sales_region_id = s.sales_region_id
group by
	r.region_name,
    order_date,
    year(order_date)
order by 
	order_date,
    sales_year,
    sales_amount desc;

#task 4, 6

select
	max(p.category)
from Sales s
inner join Product p
on s.product_id = p.product_id;

#task 4, 7
#approccio 1

select
	p.product_id,
    p.product_name,
    s.sales_order_id
from Product p
left join Sales s
on p.product_id = s.product_id
where s.sales_order_id is null;

#approccio 2

select
	p.product_id,
    p.product_name,
    sum(quantity) as total_quantity
from Product p
left join Sales s
on p.product_id = s.product_id
group by
	p.product_id,
    p.product_name
having sum(quantity) <= 0
or sum(quantity) is null;

#task 4, 8

create view product_denormalizzata as (
	select
		product_id,
        product_name,
        category
	from Product);
select *
from product_denormalizzata;

#task 4, 9

create view geographic_info as (
	select
		sales_region_id,
        sales_region_name,
        region_name
	from Region);
select *
from geographic_info;
